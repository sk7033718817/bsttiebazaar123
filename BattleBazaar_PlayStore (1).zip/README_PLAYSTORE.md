# BattleBazaar: Play Store guide (Hinglish)

Is folder ki website ab installable app (PWA) hai. Play Store ke liye isse Android app (AAB) mein badalna hai.

## Folder mein kya hai
- index.html, manifest.webmanifest, sw.js, icons/   -> website + app files
- privacy.html                -> privacy policy (apna email daalo)
- .well-known/assetlinks.json -> step 4 mein fingerprint daalna hai
- play-store-assets/          -> 512x512 icon aur 1024x500 feature graphic

## Steps
1. **Website HTTPS par host karo (free).** Netlify, Cloudflare Pages ya GitHub Pages par poora folder upload karo.
   Example: https://battlebazaar.netlify.app  (.well-known folder bhi upload hona chahiye)
2. **Test:** https://www.pwabuilder.com par apna link daalo. Manifest aur service worker green aane chahiye.
3. **Android package banao:** PWABuilder -> Package for stores -> Android -> Google Play.
   Package ID: in.battlebazaar.app (ya apna). "Signing key" generate karwao aur **key file + password kahin safe save karo.** Kho gayi to app update nahi kar paoge.
   Download mein .aab file milegi aur ek assetlinks.json ka fingerprint.
4. **assetlinks.json update karo:** fingerprint paste karke site par dobara upload karo. Isse app mein upar wali browser bar nahi dikhti.
5. **Play Console:** play.google.com/console par developer account banao (one-time $25).
   Naya app -> .aab upload karo -> store listing mein icon (512), feature graphic, screenshots (phone ke kam se kam 2) lagao.
   Privacy policy URL: https://tumhari-site/privacy.html
   Data safety form, content rating aur target audience bharo.
6. **Naye personal developer account ke liye:** production se pehle closed testing mein kam se kam 12 testers ko 14 din tak app chalani padti hai (Google ka current rule, Play Console mein dobara check kar lena).

## Review mein ye cheezein dhyan rakho
- **Free Fire, BGMI, COD ke naam/logo:** ye dusri companies ke trademark hain. App ke naam, icon aur screenshots mein unke logo mat lagao. Description mein "players ke liye" jaisa likhna thik hai, "official" mat likho.
- **Paise wale matches:** agar entry fee ya cash prize hoga to Play ki real-money gaming policy lagti hai (license/eligibility). Abhi sirf points/badges hain, to usi par raho.
- **Login:** abhi account sirf usi phone par save hota hai. Phone badalne ya app delete karne par account chala jayega. Launch se pehle Firebase/Supabase jodna better hai.
- **Screen capture:** Android par browser/TWA mein ye aksar kaam nahi karta. Play Store listing mein iska wada mat karo.
